// SPDX-License-Identifier: GPL-2.0
// ebpf_sensor.c — eBPF Security Sensor
// Compile: clang -O2 -target bpf -c ebpf_sensor.c -o ebpf_sensor.o
// Or load via BCC: sensor_loader.py handles compilation at runtime

#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <linux/sched.h>
#include <linux/ptrace.h>
#include <linux/types.h>

// ─── Data Structures ──────────────────────────────────────────────────────

struct session_t {
    __u64 session_id;       // hash(netns_inode ^ pid ^ entry_ts)
    __u32 root_pid;         // topmost process in this session
    __u32 uid_original;     // uid at session creation
    __u32 uid_current;      // tracks setuid() flips
    __u64 entry_ts;         // ktime_get_ns() at first event
    __u64 last_event_ts;    // for gap-based session expiry
    __u32 score;            // cumulative threat score
    __u32 flags;            // bitmask: R001..R010 triggered rules
    __u32 netns_inode;      // network namespace fingerprint
    __u8  alerted;          // have we emitted a ALERT event?
};

struct event_t {
    __u64 timestamp;
    __u32 pid;
    __u32 ppid;
    __u32 syscall_nr;
    __u64 session_id;
    __u32 score_delta;
    char  comm[16];
    char  path[64];
    __u8  cat;              // 0=exec 1=net 2=fs 3=priv
};

// ─── Maps ─────────────────────────────────────────────────────────────────

// Per-PID session tracking
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 4096);
    __type(key,   __u32);
    __type(value, struct session_t);
} sessions SEC(".maps");

// Zero-copy ring buffer → userspace
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 20);   // 1 MB
} events SEC(".maps");

// pid → ppid inheritance for session chaining
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 8192);
    __type(key,   __u32);   // child pid
    __type(value, __u32);   // parent pid
} pid_tree SEC(".maps");

// ─── Helpers ──────────────────────────────────────────────────────────────

static __always_inline struct session_t *
get_or_create_session(__u32 pid, __u32 uid)
{
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (sess) return sess;

    // Inherit from parent if possible
    __u32 *ppid_p = bpf_map_lookup_elem(&pid_tree, &pid);
    if (ppid_p) {
        struct session_t *parent = bpf_map_lookup_elem(&sessions, ppid_p);
        if (parent) {
            // Fork inherits parent session
            bpf_map_update_elem(&sessions, &pid, parent, BPF_NOEXIST);
            return bpf_map_lookup_elem(&sessions, &pid);
        }
    }

    struct session_t new = {};
    new.session_id   = bpf_ktime_get_ns() ^ ((__u64)pid << 32);
    new.root_pid     = pid;
    new.uid_original = uid;
    new.uid_current  = uid;
    new.entry_ts     = bpf_ktime_get_ns();
    new.score        = 0;
    bpf_map_update_elem(&sessions, &pid, &new, BPF_NOEXIST);
    return bpf_map_lookup_elem(&sessions, &pid);
}

static __always_inline struct event_t *
emit_event(__u32 pid, __u32 syscall_nr, __u64 session_id, __u32 delta, __u8 cat)
{
    struct event_t *e = bpf_ringbuf_reserve(&events, sizeof(*e), 0);
    if (!e) return NULL;
    e->timestamp   = bpf_ktime_get_ns();
    e->pid         = pid;
    e->syscall_nr  = syscall_nr;
    e->session_id  = session_id;
    e->score_delta = delta;
    e->cat         = cat;
    bpf_get_current_comm(&e->comm, sizeof(e->comm));
    return e;
}

// ─── Probes ───────────────────────────────────────────────────────────────

SEC("tracepoint/syscalls/sys_enter_execve")
int trace_execve(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    struct session_t *sess = get_or_create_session(pid, uid);
    if (!sess) return 0;
    sess->score += 5;
    sess->last_event_ts = bpf_ktime_get_ns();

    struct event_t *e = emit_event(pid, 59, sess->session_id, 5, 0);
    if (!e) return 0;
    bpf_probe_read_user_str(&e->path, sizeof(e->path), (void *)ctx->args[0]);
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_execveat")
int trace_execveat(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    struct session_t *sess = get_or_create_session(pid, uid);
    if (!sess) return 0;
    sess->score += 8;   // execveat scores higher (often fileless)
    struct event_t *e = emit_event(pid, 322, sess->session_id, 8, 0);
    if (!e) return 0;
    bpf_probe_read_user_str(&e->path, sizeof(e->path), (void *)ctx->args[1]);
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_clone")
int trace_clone(struct trace_event_raw_sys_enter *ctx)
{
    __u64 pid_tgid = bpf_get_current_pid_tgid();
    __u32 pid = pid_tgid >> 32;
    // Child PID inheritance recorded in sys_exit_clone
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (sess) { sess->score += 3; sess->last_event_ts = bpf_ktime_get_ns(); }
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_openat")
int trace_openat(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    struct session_t *sess = get_or_create_session(pid, uid);
    if (!sess) return 0;

    char path[64];
    bpf_probe_read_user_str(path, sizeof(path), (void *)ctx->args[1]);

    __u32 delta = 3;
    // Heuristic path scoring (byte comparisons stay verifier-safe)
    if (path[1]=='e' && path[4]=='/' && path[5]=='s') delta = 35; // /etc/shadow
    if (path[1]=='e' && path[4]=='/' && path[5]=='p') delta = 20; // /etc/passwd
    if (path[1]=='r' && path[2]=='o' && path[3]=='o') delta = 35; // /root/
    if (path[1]=='.' && path[2]=='s' && path[3]=='s') delta = 40; // /.ssh/

    sess->score += delta;
    if (delta >= 20) sess->flags |= (1 << 0);   // R001
    sess->last_event_ts = bpf_ktime_get_ns();

    struct event_t *e = emit_event(pid, 257, sess->session_id, delta, 2);
    if (!e) return 0;
    __builtin_memcpy(e->path, path, sizeof(e->path));
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_getdents64")
int trace_getdents64(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 8;
    sess->flags |= (1 << 6);   // R007 directory enumeration
    sess->last_event_ts = bpf_ktime_get_ns();
    struct event_t *e = emit_event(pid, 217, sess->session_id, 8, 2);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_socket")
int trace_socket(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    struct session_t *sess = get_or_create_session(pid, uid);
    if (!sess) return 0;

    __u32 family = (__u32)ctx->args[0];
    __u32 delta  = (family == 17) ? 40 : 20;   // AF_PACKET=17 → raw socket
    sess->score += delta;
    sess->flags |= (1 << 1);   // R002
    sess->last_event_ts = bpf_ktime_get_ns();

    struct event_t *e = emit_event(pid, 41, sess->session_id, delta, 1);
    if (!e) return 0;
    if (family == 17) __builtin_memcpy(e->path, "AF_PACKET", 10);
    else              __builtin_memcpy(e->path, "AF_INET",   8);
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_connect")
int trace_connect(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 15;
    sess->flags |= (1 << 8);   // R009
    sess->last_event_ts = bpf_ktime_get_ns();
    struct event_t *e = emit_event(pid, 42, sess->session_id, 15, 1);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_bind")
int trace_bind(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 30;
    sess->flags |= (1 << 9);   // R010
    struct event_t *e = emit_event(pid, 49, sess->session_id, 30, 1);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_accept")
int trace_accept(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 25;
    struct event_t *e = emit_event(pid, 43, sess->session_id, 25, 1);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_setuid")
int trace_setuid(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 new_uid = (__u32)ctx->args[0];
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->uid_current = new_uid;
    sess->score += 80;
    sess->flags |= (1 << 5);   // R006
    sess->last_event_ts = bpf_ktime_get_ns();
    struct event_t *e = emit_event(pid, 105, sess->session_id, 80, 3);
    if (!e) return 0;
    __builtin_memcpy(e->path, "uid=0", 6);
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_ptrace")
int trace_ptrace(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 40;
    sess->flags |= (1 << 7);   // R008
    struct event_t *e = emit_event(pid, 101, sess->session_id, 40, 3);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_memfd_create")
int trace_memfd_create(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    struct session_t *sess = get_or_create_session(pid, uid);
    if (!sess) return 0;
    sess->score += 70;
    sess->flags |= (1 << 2);   // R003 fileless
    struct event_t *e = emit_event(pid, 319, sess->session_id, 70, 3);
    if (!e) return 0;
    bpf_probe_read_user_str(&e->path, sizeof(e->path), (void *)ctx->args[0]);
    bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_setns")
int trace_setns(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 50;
    sess->flags |= (1 << 4);   // R005
    struct event_t *e = emit_event(pid, 308, sess->session_id, 50, 3);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_ftruncate")
int trace_ftruncate(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    struct session_t *sess = bpf_map_lookup_elem(&sessions, &pid);
    if (!sess) return 0;
    sess->score += 60;
    sess->flags |= (1 << 3);   // R004 log wiping
    struct event_t *e = emit_event(pid, 77, sess->session_id, 60, 2);
    if (e) bpf_ringbuf_submit(e, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
