#!/usr/bin/env python3
"""
sensor_loader.py — eBPF Security Sensor loader via BCC
Requirements: pip install bcc
Run as root:  sudo python3 sensor_loader.py

Outputs structured JSON session data on exit (Ctrl-C).
"""

from bcc import BPF
import ctypes, json, time, os, signal, sys, argparse
from datetime import datetime
from pathlib import Path

# ── Config ────────────────────────────────────────────────────────────────
SCORE_THRESHOLD = 100
SESSION_TIMEOUT = 300       # seconds of inactivity → expire session
POLL_INTERVAL   = 0.05      # ring buffer poll interval (seconds)
EXPIRE_INTERVAL = 30        # how often to sweep for expired sessions
OUTPUT_FILE     = "sessions_dump.json"

SYSCALL_NAMES = {
    0: "read",       1: "write",      2: "open",
    42: "connect",   43: "accept",    44: "sendto",
    45: "recvfrom",  49: "bind",      56: "clone",
    57: "fork",      59: "execve",    77: "ftruncate",
    80: "chdir",     87: "unlink",    92: "chown",
    101: "ptrace",   105: "setuid",   106: "setgid",
    157: "prctl",    217: "getdents64", 257: "openat",
    308: "setns",    319: "memfd_create", 322: "execveat",
}

CATEGORY_NAMES = {0: "exec", 1: "net", 2: "fs", 3: "priv"}

# ── Event struct (must match ebpf_sensor.c) ────────────────────────────────
class SensorEvent(ctypes.Structure):
    _fields_ = [
        ("timestamp",   ctypes.c_uint64),
        ("pid",         ctypes.c_uint32),
        ("ppid",        ctypes.c_uint32),
        ("syscall_nr",  ctypes.c_uint32),
        ("session_id",  ctypes.c_uint64),
        ("score_delta", ctypes.c_uint32),
        ("comm",        ctypes.c_char * 16),
        ("path",        ctypes.c_char * 64),
        ("cat",         ctypes.c_uint8),
    ]

# ── State ─────────────────────────────────────────────────────────────────
sessions    = {}        # session_id → dict
alerts      = []        # list of alert dicts
event_count = 0
start_time  = time.time()

# ── Handlers ──────────────────────────────────────────────────────────────
def handle_event(cpu, data, size):
    global event_count
    event = ctypes.cast(data, ctypes.POINTER(SensorEvent)).contents
    sid   = event.session_id
    pid   = event.pid
    sc_nr = event.syscall_nr
    sc    = SYSCALL_NAMES.get(sc_nr, f"sc#{sc_nr}")
    path  = event.path.decode("utf-8", errors="replace").rstrip("\x00")
    comm  = event.comm.decode("utf-8", errors="replace").rstrip("\x00")
    cat   = CATEGORY_NAMES.get(event.cat, "?")
    delta = event.score_delta
    ts    = datetime.now().strftime("%H:%M:%S.%f")[:-3]

    if sid not in sessions:
        sessions[sid] = {
            "session_id":  f"{sid:#x}",
            "pid":         pid,
            "score":       0,
            "chain":       [],
            "events":      [],
            "start":       time.time(),
            "last":        time.time(),
            "alerted":     False,
        }

    s = sessions[sid]
    s["score"]  += delta
    s["last"]    = time.time()
    s["chain"].append(sc)
    s["events"].append({"ts": ts, "sc": sc, "pid": pid, "path": path, "delta": delta, "cat": cat})
    event_count += 1

    # Colorize output
    color = "\033[0m"
    if cat == "priv": color = "\033[91m"    # red
    elif cat == "net": color = "\033[93m"   # yellow
    elif cat == "exec": color = "\033[94m"  # blue

    print(f"{color}[{ts}] {sc:18s} pid={pid:<6} score={s['score']:<5} {path[:40]}\033[0m")

    if s["score"] > SCORE_THRESHOLD and not s["alerted"]:
        s["alerted"] = True
        chain_tail = s["chain"][-6:]
        print(f"\n\033[41;97m{'='*65}\033[0m")
        print(f"\033[91m[ALERT] session={sid:#x}  score={s['score']}\033[0m")
        print(f"\033[91m        pid={pid}  comm={comm}\033[0m")
        print(f"\033[91m        chain={' → '.join(chain_tail)}\033[0m")
        print(f"\033[41;97m{'='*65}\033[0m\n")
        alerts.append({
            "session_id": f"{sid:#x}",
            "score": s["score"],
            "pid": pid,
            "comm": comm,
            "chain": chain_tail,
            "ts": ts,
        })


def expire_sessions():
    now = time.time()
    expired = [sid for sid, s in sessions.items() if now - s["last"] > SESSION_TIMEOUT]
    for sid in expired:
        s = sessions[sid]
        print(f"\033[90m[SESSION END] {sid:#x} — score={s['score']} events={len(s['chain'])}\033[0m")
        del sessions[sid]


def dump_and_exit(sig=None, frame=None):
    print("\n\033[96mDumping session data…\033[0m")
    out = {
        "meta": {
            "duration_s": round(time.time() - start_time, 1),
            "total_events": event_count,
            "total_alerts": len(alerts),
            "threshold": SCORE_THRESHOLD,
        },
        "alerts":   alerts,
        "sessions": {f"{sid:#x}": {**s, "session_id": f"{sid:#x}"}
                     for sid, s in sessions.items()},
    }
    path = Path(OUTPUT_FILE)
    path.write_text(json.dumps(out, indent=2, default=str))
    print(f"\033[92mSaved → {path.resolve()}\033[0m")
    sys.exit(0)


# ── Main ──────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="eBPF Security Sensor")
    parser.add_argument("--threshold", type=int, default=SCORE_THRESHOLD,
                        help="Alert score threshold (default: 100)")
    parser.add_argument("--output",    default=OUTPUT_FILE,
                        help="JSON dump file on exit")
    parser.add_argument("--src",       default="ebpf_sensor.c",
                        help="Path to eBPF C source")
    args = parser.parse_args()

    global SCORE_THRESHOLD, OUTPUT_FILE
    SCORE_THRESHOLD = args.threshold
    OUTPUT_FILE     = args.output

    if os.geteuid() != 0:
        print("\033[91mError: must run as root (sudo python3 sensor_loader.py)\033[0m")
        sys.exit(1)

    src_path = Path(args.src)
    if not src_path.exists():
        # Try sibling directory
        alt = Path(__file__).parent / "ebpf_sensor.c"
        if alt.exists():
            src_path = alt
        else:
            print(f"\033[91mError: cannot find {args.src}\033[0m")
            sys.exit(1)

    print(f"\033[96m{'─'*60}")
    print(f"  eBPF Security Sensor")
    print(f"  Source:    {src_path}")
    print(f"  Threshold: {SCORE_THRESHOLD}")
    print(f"  Output:    {OUTPUT_FILE}")
    print(f"{'─'*60}\033[0m")

    b = BPF(src_file=str(src_path))
    b["events"].open_ring_buffer(handle_event)

    signal.signal(signal.SIGINT,  dump_and_exit)
    signal.signal(signal.SIGTERM, dump_and_exit)

    print(f"\033[92mSensor running (PID {os.getpid()}). Ctrl-C to stop & dump.\033[0m\n")
    print(f"{'TIME':12s} {'SYSCALL':18s} {'PID':8s} {'SCORE':7s} {'PATH'}")
    print("─" * 70)

    expire_tick = time.time()
    while True:
        b.ring_buffer_poll()
        if time.time() - expire_tick > EXPIRE_INTERVAL:
            expire_sessions()
            expire_tick = time.time()
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
